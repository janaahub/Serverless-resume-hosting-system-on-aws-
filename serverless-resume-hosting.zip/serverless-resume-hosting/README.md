# Serverless Resume Hosting System on AWS

B.Tech Information Technology project - M Janaranjani
University College of Engineering (BIT Campus), Anna University

Hosts a resume (PDF) as a shareable HTTPS link using AWS serverless services.

## Architecture

```
Flow 1 (core):     Browser -> CloudFront -> S3 (private bucket, Origin Access Control)
Flow 2 (optional): Browser -> API Gateway (HTTP API) -> Lambda -> DynamoDB
Supporting:        IAM (least privilege) + CloudWatch (logs)
```

| Service | Role | Type |
|---|---|---|
| Amazon S3 | Stores the resume and site files (private) | Core |
| Amazon CloudFront | Serves content over HTTPS, cached | Core |
| API Gateway | Receives contact form requests | Optional |
| AWS Lambda | Validates and processes the form | Optional |
| DynamoDB | Stores contact submissions | Optional |
| IAM / CloudWatch | Access control, logs | Supporting |

## Project structure

```
template.yaml            SAM/CloudFormation template (all infrastructure)
lambda/contact/app.py    Contact form Lambda (Python 3.12)
website/                 Static site (index.html, styles, JS)
website/resume/          PUT YOUR resume.pdf HERE
scripts/deploy.sh        One-command deploy + upload
scripts/destroy.sh       Clean-up to avoid charges
```

## Prerequisites

- AWS account and an IAM user/role with permission to create the resources
- [AWS CLI](https://docs.aws.amazon.com/cli/latest/userguide/getting-started-install.html), configured with `aws configure`
- [AWS SAM CLI](https://docs.aws.amazon.com/serverless-application-model/latest/developerguide/install-sam-cli.html)
- Python 3 (needed by SAM build and destroy.sh)

## Deploy

1. Copy your resume to `website/resume/resume.pdf`.
2. Run:
   ```bash
   chmod +x scripts/*.sh
   ./scripts/deploy.sh serverless-resume us-east-1
   ```
3. The script prints your shareable URL (`https://dxxxx.cloudfront.net`) and the PDF link.

To deploy **without** the contact form (core only):
```bash
sam deploy --parameter-overrides EnableContactForm=false
```
(then upload `website/` with `aws s3 sync`; the form hides itself when no API is configured).

### Update the resume later
Replace `website/resume/resume.pdf` and run `./scripts/deploy.sh` again.

### Tighten CORS (recommended)
After the first deploy, restrict the API to your site:
```bash
sam deploy --parameter-overrides AllowedOrigin=https://dxxxx.cloudfront.net
```

## Test

1. Open the CloudFront URL - the PDF should display; "Download PDF" should save it.
2. Submit the contact form, then check DynamoDB:
   ```bash
   aws dynamodb scan --table-name <ContactTableName from stack outputs>
   ```
3. View Lambda logs in CloudWatch: `sam logs --stack-name serverless-resume --tail`

## Security

- S3 bucket is private (all public access blocked); only CloudFront can read it via OAC
- HTTPS enforced (HTTP redirects to HTTPS; bucket denies non-TLS access)
- Lambda role can only `dynamodb:PutItem` on its own table (least privilege)
- Contact input validated (lengths, email format, honeypot) and API throttled
- Set a billing alert in AWS Billing > Budgets

## Cost

Everything used is pay-per-use and mostly within the Free Tier for a personal resume, but Free Tier has limits. Check current AWS pricing, and run `./scripts/destroy.sh` when you no longer need the site.

## Future enhancements

Custom domain with Route 53, authentication for private uploads, resume version history (S3 versioning is already enabled), CI/CD pipeline and usage analytics.
