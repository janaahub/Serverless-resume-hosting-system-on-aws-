(function () {
  var cfg = window.APP_CONFIG || {};
  var section = document.getElementById("contact-section");
  var form = document.getElementById("contact-form");
  var status = document.getElementById("form-status");

  // Hide the optional contact form when no API is configured
  if (!cfg.CONTACT_API_URL) {
    if (section) section.hidden = true;
    return;
  }

  function setStatus(msg, cls) {
    status.textContent = msg;
    status.className = cls || "";
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var data = Object.fromEntries(new FormData(form).entries());

    if (!data.name || !data.email || !data.message) {
      setStatus("Please fill in all fields.", "err");
      return;
    }

    var btn = form.querySelector("button[type=submit]");
    btn.disabled = true;
    setStatus("Sending...");

    fetch(cfg.CONTACT_API_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    })
      .then(function (res) {
        return res.json().then(function (body) { return { ok: res.ok, body: body }; });
      })
      .then(function (r) {
        if (r.ok) {
          setStatus(r.body.message || "Message sent!", "ok");
          form.reset();
        } else {
          setStatus(r.body.error || "Something went wrong.", "err");
        }
      })
      .catch(function () {
        setStatus("Network error. Please try again.", "err");
      })
      .then(function () { btn.disabled = false; });
  });
})();
