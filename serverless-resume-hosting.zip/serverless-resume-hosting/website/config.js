// Set automatically by scripts/deploy.sh after the stack is created.
// Leave CONTACT_API_URL empty to hide the optional contact form.
window.APP_CONFIG = {
  CONTACT_API_URL: ""
};
