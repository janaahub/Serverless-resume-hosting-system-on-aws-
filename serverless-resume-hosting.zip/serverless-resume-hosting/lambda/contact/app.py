"""Contact form handler: validates input and stores the message in DynamoDB."""
import base64
import json
import logging
import os
import re
import time
import uuid

import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)

TABLE = boto3.resource("dynamodb").Table(os.environ["TABLE_NAME"])

EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
MAX_NAME, MAX_EMAIL, MAX_MESSAGE = 100, 254, 2000


def _response(status, body):
    return {
        "statusCode": status,
        "headers": {"Content-Type": "application/json"},
        "body": json.dumps(body),
    }


def _validate(data):
    name = str(data.get("name", "")).strip()
    email = str(data.get("email", "")).strip()
    message = str(data.get("message", "")).strip()

    if not name or len(name) > MAX_NAME:
        return None, f"Name is required (max {MAX_NAME} characters)."
    if not EMAIL_RE.match(email) or len(email) > MAX_EMAIL:
        return None, "A valid email address is required."
    if not message or len(message) > MAX_MESSAGE:
        return None, f"Message is required (max {MAX_MESSAGE} characters)."
    # Honeypot field: real users leave it empty
    if str(data.get("website", "")).strip():
        return None, "Rejected."
    return {"name": name, "email": email, "message": message}, None


def handler(event, context):
    try:
        raw = event.get("body") or "{}"
        if event.get("isBase64Encoded"):
            raw = base64.b64decode(raw).decode("utf-8")
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise ValueError("body must be a JSON object")
    except (ValueError, UnicodeDecodeError):
        return _response(400, {"error": "Invalid JSON body."})

    clean, error = _validate(data)
    if error:
        return _response(400, {"error": error})

    item = {
        "id": str(uuid.uuid4()),
        "createdAt": int(time.time()),
        **clean,
    }
    try:
        TABLE.put_item(Item=item)
    except Exception:  # noqa: BLE001
        logger.exception("Failed to save contact submission")
        return _response(500, {"error": "Could not save your message. Please try again."})

    logger.info("Saved contact submission %s", item["id"])
    return _response(200, {"message": "Thanks! Your message has been received."})
