#!/usr/bin/env bash
# Removes everything to avoid unexpected AWS charges.
# Usage: ./scripts/destroy.sh [stack-name] [region]
set -euo pipefail

STACK="${1:-serverless-resume}"
REGION="${2:-${AWS_REGION:-us-east-1}}"

BUCKET="$(aws cloudformation describe-stacks --stack-name "$STACK" --region "$REGION" \
  --query "Stacks[0].Outputs[?OutputKey=='BucketName'].OutputValue | [0]" --output text)"

read -r -p "Delete stack '$STACK' and ALL files in bucket '$BUCKET'? [y/N] " ans
[[ "$ans" =~ ^[Yy]$ ]] || { echo "Cancelled."; exit 0; }

echo "==> Emptying bucket (including old versions)"
python3 - "$BUCKET" "$REGION" <<'PY'
import sys, boto3
bucket, region = sys.argv[1], sys.argv[2]
boto3.resource("s3", region_name=region).Bucket(bucket).object_versions.delete()
PY

echo "==> Deleting stack"
aws cloudformation delete-stack --stack-name "$STACK" --region "$REGION"
aws cloudformation wait stack-delete-complete --stack-name "$STACK" --region "$REGION"
echo "Deleted."
