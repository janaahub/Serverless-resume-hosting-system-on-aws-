#!/usr/bin/env bash
# Deploys the stack, uploads the website + resume, and invalidates the CloudFront cache.
# Usage: ./scripts/deploy.sh [stack-name] [region]
set -euo pipefail

STACK="${1:-serverless-resume}"
REGION="${2:-${AWS_REGION:-us-east-1}}"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"

command -v aws >/dev/null || { echo "AWS CLI not found. Install it first."; exit 1; }
command -v sam >/dev/null || { echo "AWS SAM CLI not found. Install it first."; exit 1; }

if [[ ! -f "$ROOT/website/resume/resume.pdf" ]]; then
  echo "Missing website/resume/resume.pdf - copy your resume there first."
  exit 1
fi

echo "==> Building and deploying stack '$STACK' in $REGION"
cd "$ROOT"
sam build --template-file template.yaml
sam deploy \
  --stack-name "$STACK" \
  --region "$REGION" \
  --resolve-s3 \
  --capabilities CAPABILITY_IAM \
  --no-confirm-changeset \
  --no-fail-on-empty-changeset

out() {
  aws cloudformation describe-stacks --stack-name "$STACK" --region "$REGION" \
    --query "Stacks[0].Outputs[?OutputKey=='$1'].OutputValue | [0]" --output text
}

BUCKET="$(out BucketName)"
DIST_ID="$(out DistributionId)"
SITE_URL="$(out ResumeUrl)"
API_URL="$(out ContactApiUrl 2>/dev/null || true)"
[[ "$API_URL" == "None" ]] && API_URL=""

echo "==> Writing website config"
TMP_SITE="$(mktemp -d)"
cp -R "$ROOT/website/." "$TMP_SITE/"
cat > "$TMP_SITE/config.js" <<EOF
window.APP_CONFIG = {
  CONTACT_API_URL: "${API_URL}"
};
EOF

echo "==> Uploading to s3://$BUCKET"
# Long cache for the PDF is avoided so updates show quickly
aws s3 sync "$TMP_SITE" "s3://$BUCKET" --region "$REGION" --delete \
  --cache-control "public, max-age=300"
rm -rf "$TMP_SITE"

echo "==> Invalidating CloudFront cache"
aws cloudfront create-invalidation --distribution-id "$DIST_ID" --paths "/*" >/dev/null

echo
echo "Done!"
echo "Resume site : $SITE_URL"
echo "Resume PDF  : $SITE_URL/resume/resume.pdf"
[[ -n "$API_URL" ]] && echo "Contact API : $API_URL"
echo
echo "Tip: tighten CORS by redeploying with --parameter-overrides AllowedOrigin=$SITE_URL"
